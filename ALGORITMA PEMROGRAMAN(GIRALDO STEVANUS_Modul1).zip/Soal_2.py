indeks = {
    "Rupiah     ":  "Rp",
    "Dolar      ":  "$",
    }
print("============== Indeks Menghitung Nilai Mata Uang=============")

#konversi mata uang
idr = int(input("Masukkan Nilai Rupiah :"))
usd = int(input("Masukkan Nilai Dolar :"))

kurs_dollar = 14500
konversi1 = int(idr/kurs_dollar)
konversi2 = usd*kurs_dollar
print(f'Hasil setelah dikonversi ke $: {konversi1} \n Hasil setelah di konversi ke Rp: {konversi2}')