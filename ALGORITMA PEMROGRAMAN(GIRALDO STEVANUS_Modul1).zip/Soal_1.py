print (40*"=")

harga = int(input("masukkan harga : "))
diskon = int(input("masukkan diskon : "))
hasil = harga-harga*diskon/100
print("hasil diskon adalah : ", hasil)
